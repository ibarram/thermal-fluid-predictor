/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;

/* USER CODE BEGIN PV */

#define CS_HIGH() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)
#define CS_LOW()  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET)
uint8_t spi_rx_buf[4];
char uart_buf[64];

/*Variables para los mensajes de los sensores de temperatura*/
uint16_t rawValues[4];
char msgT[20]; //100

/*Variables para el termistor de entrada*/
float VoltageThermi_In_mV;
float Thermistor_In_Voltage;
float R_ThermIn;
float Termino_R_In;
float TempThermistor_In;

/*Variables para el termistor de salida*/
float VoltageThermi_Out_mV;
float Thermistor_Out_Voltage;
float R_ThermOut;
float Termino_R_Out;
float TempThermistor_Out;

/*Valores de las constantes de conversion*/
#define C0				-0.0004304559237//0.000690748589120743   //-0.01528438318  Segundos valores testeados
#define C1				0.000311067401//0.000199679375416446   //0.002290107823
#define C2				0.0000001525474865//0.000000236877367079   //-0.000004957316956
#define R_REFIn			100000

/*Voltaje de Referencia (Diodo limitador de voltaje)*/
float V_REF;
float V_REF_3V;

/*Variable para recepcion de datos de Spark*/
uint8_t rx_data_S;

/*Variables para el contador de frecuencia*/
uint32_t IC_Value1 = 0;
uint32_t IC_Value2 = 0;
uint32_t Difference =0;
uint32_t Frequency = 0;

/*Variable de Bandera para restaurar el muestreo*/
uint8_t Is_First_Captured = 0;

/*Variable para impresion de valores de Frecuencia y Flujo*/
char msgF[100];

/*Variables para la lectura del PWM*/
uint8_t rx_data_PWM;

uint16_t duty = 0;
uint16_t maxDuty = 0;

volatile uint8_t rx_ready_PWM = 0;

char msgPWM[100];


char rx_buffer[10];  // Buffer para recibir el dato completo
uint8_t rx_index = 0;


/*uint8_t rxData;  // Variable para recibir un carácter
#define BUFFER_SIZE 50  // Tamaño del buffer de recepción
char rxBuffer[BUFFER_SIZE];  // Buffer para almacenar los datos recibidos
uint8_t rxIndex = 0;  // Índice del buffer
*/
uint8_t rxIndex = 0;  // Índice del buffer
uint8_t rxBuffer[20];  // Buffer para recibir 3 caracteres a la vez

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);
static void MX_SPI2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*Variables tipo bandera para reinicio de captura del ADC(sensores temperatura)*/
uint8_t convCompleted_ADC = 0;
uint8_t rx_ready_spark = 0;

/*Funcion para la lectura del ADC*/
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	convCompleted_ADC = 1;
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)
	{
		if (Is_First_Captured == 0)
		{
			IC_Value1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			Is_First_Captured = 1;
		}

		else if (Is_First_Captured == 1)
		{
			IC_Value2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			if (IC_Value2 > IC_Value1)
			{
				Difference = IC_Value2 - IC_Value1;
			}

			else if(IC_Value2 < IC_Value1)
			{
				Difference = ((0xffff - IC_Value1) + IC_Value2) + 1;
			}

			else
			{
				Difference = 1;
			}

			Frequency = HAL_RCC_GetPCLK1Freq() / Difference;
			Frequency = (1.003 * Frequency) + 0.5;

			if (Frequency > 128000){Frequency=128000;}
			//if (Frequency < 128){Frequency=0;}

			Is_First_Captured = 0;
		}
	}
}


float read_thermocouple_temp(void) {
    uint32_t value = 0;

    CS_LOW();
    HAL_SPI_Receive(&hspi2, spi_rx_buf, 4, 100);
    CS_HIGH();

    value = (spi_rx_buf[0] << 24) | (spi_rx_buf[1] << 16) | (spi_rx_buf[2] << 8) | spi_rx_buf[3];

    // Verificar si hay error (bit D16)
    if (value & 0x00010000) {
        return -1000.0f;  // Error
    }

    // Temperatura del termopar (bits 31:18, 14 bits con signo)
    int16_t temp_raw = (value >> 18) & 0x3FFF;
    if (temp_raw & 0x2000) temp_raw |= 0xC000;  // Sign extend negativo

    return temp_raw * 0.25f;
}

void send_temperature_uart(float temp) {
    int len = snprintf(uart_buf, sizeof(uart_buf), "Temper: %.2f \r\n", temp);
    HAL_UART_Transmit(&huart2, (uint8_t *)uart_buf, len, HAL_MAX_DELAY);
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_SPI2_Init();
  /* USER CODE BEGIN 2 */
  /*Inicializar el Convertidor ADC*/
  HAL_ADC_Start_DMA(&hadc1, (uint32_t *) rawValues, 4);
  /*Inicializar la recepcion de datos*/
  //HAL_UART_Receive_IT(&huart2, &rxData, 1);
  HAL_UART_Receive_IT(&huart2, rxBuffer, sizeof(rxBuffer)); // Recibir 3 bytes en vez de 1
  /*Inicializar el timer*/
  HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
  /*Inicializar Timer 4 para PWM*/
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
  maxDuty = htim4.Instance->ARR;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	    /* USER CODE END WHILE */

		  convCompleted_ADC = 0;  // Reiniciar la bandera del ADC

		  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)rawValues, 4);  // Reiniciar la conversión ADC-DMA

		  while(!convCompleted_ADC);  // Esperar a que la conversión termine del ADC
		  {

		  /*Obtener el Valor de Referencia del voltaje*/
		  //float V_REF_mV = rawValues[2];
		  //V_REF = (float)V_REF_mV/1000;
		  V_REF = ((float)rawValues[2] / 4095.0) * 3.3;

		  /*Lectura del Termistor de entrada*/
		  VoltageThermi_In_mV = rawValues[0];
		  //Thermistor_In_Voltage = (float)VoltageThermi_In_mV/1000;
		  Thermistor_In_Voltage = ((float)rawValues[0] / 4095.0) * 3.3;
		  R_ThermIn = (R_REFIn / Thermistor_In_Voltage)*V_REF-R_REFIn;
		  Termino_R_In = C0 + C1*logf(R_ThermIn) + C2*powf(logf(R_ThermIn),3);
		  TempThermistor_In = (1/Termino_R_In)-273.15;
		  uint16_t temp_value_In = (uint16_t)TempThermistor_In;
		  sprintf(msgT, "Pot1: %.4f \r\n", TempThermistor_In);
		  //sprintf(msgT, "Pot1: %hu \r\n", temp_value_In);
		  HAL_UART_Transmit(&huart2, (uint8_t *)msgT, strlen(msgT), HAL_MAX_DELAY);

		  /*Lectura del Termistor de salida*/
		  VoltageThermi_Out_mV = rawValues[1];
		  //Thermistor_Out_Voltage = (float)VoltageThermi_Out_mV/1000;
		  Thermistor_Out_Voltage = ((float)rawValues[1] / 4095.0) * 3.3;
		  R_ThermOut = (R_REFIn / Thermistor_Out_Voltage)*V_REF-R_REFIn;
		  Termino_R_Out = C0 + C1*logf(R_ThermOut) + C2*powf(logf(R_ThermOut),3);
		  TempThermistor_Out = (1/Termino_R_Out)-273.15;
		  uint16_t temp_value_Out = (uint16_t)TempThermistor_Out;
		  sprintf(msgT, "Pot2: %.4f \r\n", TempThermistor_Out);
		  //sprintf(msgT, "Pot2: %hu \r\n", temp_value_Out);
		  HAL_UART_Transmit(&huart2, (uint8_t *)msgT, strlen(msgT), HAL_MAX_DELAY);

		  uint16_t temp_value_V_REF = (uint16_t)V_REF;
		  sprintf(msgT, "Pot3: %.2f \r\n", V_REF);
		  //sprintf(msgT, "Pot3: %hu \r\n", temp_value_V_REF);
		  HAL_UART_Transmit(&huart2, (uint8_t *)msgT, strlen(msgT), HAL_MAX_DELAY);

		  //V_REF_3V = rawValues[3];
		  V_REF_3V = ((float)rawValues[3] / 4095.0) * 3.3;
		  sprintf(msgT, "Pot4: %.2f \r\n", V_REF_3V);
		  //sprintf(msgT, "Pot4: %hu \r\n", pot4);
		  HAL_UART_Transmit(&huart2, (uint8_t *)msgT, strlen(msgT), HAL_MAX_DELAY);

		  HAL_Delay(10);
		  }

		  /*if(rx_ready_spark)
		  {
			  		  // Almacenar el carácter recibido en el buffer
			  		  if (rxIndex < BUFFER_SIZE - 1) {
			  			  rxBuffer[rxIndex++] = rxData;
			  			  rxBuffer[rxIndex] = '\0'; // Agregar terminador de string
			  		  } else {
			  			  rxIndex = 0;  // Reiniciar si se llena el buffer
			  		  }

			  		  // Imprimir lo recibido en la consola UART
			  		  char msgR[100];
			  		  sprintf(msgR, "Recibido: %c\r\n", rxData);
			  		  HAL_UART_Transmit(&huart2, (uint8_t*)msgR, strlen(msgR), HAL_MAX_DELAY);

			  		  // Evaluar los caracteres recibidos
			  		  switch(rxData) {
			  		  case '0':
			  			  duty = 49;
			  			  htim4.Instance->CCR1 = duty;
			  			  sprintf(msgPWM, "Duty 10: %hu \r\n", duty);
			  			  HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
			  			  break;
			  		  case '1':
			  			  duty = 124;
			  			  htim4.Instance->CCR1 = duty;
			  			  sprintf(msgPWM, "Duty 25: %hu \r\n", duty);
			  			  HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
			  			  break;
			  		  case '2':
			  			  duty = 249;
			  			  htim4.Instance->CCR1 = duty;
			  			  sprintf(msgPWM, "Duty 50: %hu \r\n", duty);
			  			  HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
			  			  break;
			  		  case '3':
			  			  duty = 376;
			  			  htim4.Instance->CCR1 = duty;
			  			  sprintf(msgPWM, "Duty 75: %hu \r\n", duty);
			  			  HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
			  			  break;
			  		  case '4':
			  			  duty = 499;
			  			  htim4.Instance->CCR1 = duty;
			  			  sprintf(msgPWM, "Duty 100: %hu \r\n", duty);
			  			  HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
			  			  break;
			  		  case '5':
			  			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);   // Encender LED1
			  			  break;
			  		  case '6':
			  			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);   // Encender LED1
			  			  break;
			  		  case '7':
			  			  HAL_GPIO_WritePin(GPIOA, Over_Temp_Pin, GPIO_PIN_RESET); // Apagar LED2
			  			  break;
			  		  case '8':
			  			  HAL_GPIO_WritePin(GPIOA, Over_Temp_Pin, GPIO_PIN_SET);   // Encender LED2
			  			  break;
			  		  case '9':
			  			  HAL_GPIO_WritePin(GPIOA, Flame_Detec_Pin, GPIO_PIN_RESET); // Apagar LED3
			  			  break;
			  		  case 'A':
			  			  HAL_GPIO_WritePin(GPIOA, Flame_Detec_Pin, GPIO_PIN_SET);   // Encender LED3
			  			  break;
			  		  case 'B':
			  			  HAL_GPIO_WritePin(GPIOC, EV_Valve_Pin, GPIO_PIN_RESET); // Apagar LED4
			  			  break;
			  		  case 'C':
			  			  HAL_GPIO_WritePin(GPIOC, EV_Valve_Pin, GPIO_PIN_SET);   // Encender LED4
			  			  break;
			  		  default:
			  			  break;
			  		  }


			  // Reiniciar la recepción UART
			  HAL_UART_Receive_IT(&huart2, &rxData, 1);
			  //HAL_Delay(1000);
		  }*/

		  htim4.Instance->CCR1 = duty;
		  sprintf(msgPWM, "Duty: %hu \r\n", duty);
		  HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);

		  sprintf(msgF, "Freq: %lu\r\n", Frequency);
		  HAL_UART_Transmit(&huart2, (uint8_t *)msgF, strlen(msgF), HAL_MAX_DELAY);
		  //HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
		  //HAL_Delay(100);

		    // Cálculo de los pulsos por segundo y por minuto
		    uint32_t pulsosPorSegundo = Frequency;
		    uint32_t pulsosPorMinuto = Frequency * 60;

		    // Crear mensaje con los valores de pulsos y frecuencia
		    char msgPulsos[20];
		    sprintf(msgPulsos, "Pulsos/s: %lu  Pulsos/min: %lu\r\n", pulsosPorSegundo, pulsosPorMinuto);
		    HAL_UART_Transmit(&huart2, (uint8_t *)msgPulsos, strlen(msgPulsos), HAL_MAX_DELAY);

			#define FACTOR_CONVERSION 480.81  // Pulsos por litro
		    float flujo_LPM = (float)Frequency * 60.0 / FACTOR_CONVERSION;
		    char msgFlujo[20];
		    sprintf(msgFlujo, "Flujo(L/min): %.4f\r\n", flujo_LPM);
		    HAL_UART_Transmit(&huart2, (uint8_t *)msgFlujo, strlen(msgFlujo), HAL_MAX_DELAY);

		      float temp = read_thermocouple_temp();
		      if (temp > -999.0f) {
		          send_temperature_uart(temp);
		      } else {
		          HAL_UART_Transmit(&huart2, (uint8_t *)"Error leyendo el MAX31855\r\n", 28, HAL_MAX_DELAY);
		      }
		      HAL_Delay(10);
	    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 4;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 7;
  hspi2.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi2.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 80-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 250-1; //50-1
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);
  /* DMA1_Channel7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4|Spark_Pin|Over_Temp_Pin|Flame_Detec_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(EV_Valve_GPIO_Port, EV_Valve_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PA4 Spark_Pin Over_Temp_Pin Flame_Detec_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_4|Spark_Pin|Over_Temp_Pin|Flame_Detec_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : EV_Valve_Pin */
  GPIO_InitStruct.Pin = EV_Valve_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(EV_Valve_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART2)
  {
	  rx_ready_spark = 1; // Indicar que un dato fue recibido
  }
 }
*/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        //char msgS[100];

        // Recorrer el buffer para procesar cada carácter
        for (uint8_t i = 0; i < sizeof(rxBuffer); i++) {
            //sprintf(msgS, "Recibido (ASCII): %c [%d]\r\n", rxBuffer[i], rxBuffer[i]);
            //HAL_UART_Transmit(&huart2, (uint8_t*)msgS, strlen(msgS), HAL_MAX_DELAY);

            // Evaluar los caracteres recibidos y controlar los LEDs
            switch(rxBuffer[i]) {
	  		  case '0':
	  			  duty = 0;
	  			  //htim4.Instance->CCR1 = duty;
	  			  //sprintf(msgPWM, "Duty 10: %hu \r\n", duty);
	  			  //HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
	  			  break;
	  		  case '1':
	  			  duty = 110; //140
	  			  //htim4.Instance->CCR1 = duty;
	  			  //sprintf(msgPWM, "Duty 25: %hu \r\n", duty);
	  			  //HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
	  			  break;
	  		  case '2':
	  			  duty = 140; //180
	  			  //htim4.Instance->CCR1 = duty;
	  			  //sprintf(msgPWM, "Duty 50: %hu \r\n", duty);
	  			  //HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
	  			  break;
	  		  case '3':
	  			  duty = 160; //220
	  			  //htim4.Instance->CCR1 = duty;
	  			  //sprintf(msgPWM, "Duty 75: %hu \r\n", duty);
	  			  //HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
	  			  break;
	  		  case '4':
	  			  duty = 210;//249
	  			  //htim4.Instance->CCR1 = duty;
	  			  //sprintf(msgPWM, "Duty 100: %hu \r\n", duty);
	  			  //HAL_UART_Transmit(&huart2, (uint8_t *)msgPWM, strlen(msgPWM), HAL_MAX_DELAY);
	  			  break;
	  		  case '5':
	  			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);   // Encender LED1
	  			  break;
	  		  case '6':
	  			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);   // Encender LED1
	  			  break;
	  		  case '7':
	  			  HAL_GPIO_WritePin(GPIOA, Over_Temp_Pin, GPIO_PIN_RESET); // Apagar LED2
	  			  break;
	  		  case '8':
	  			  HAL_GPIO_WritePin(GPIOA, Over_Temp_Pin, GPIO_PIN_SET);   // Encender LED2
	  			  break;
	  		  case '9':
	  			  HAL_GPIO_WritePin(GPIOA, Flame_Detec_Pin, GPIO_PIN_RESET); // Apagar LED3
	  			  break;
	  		  case 'A':
	  			  HAL_GPIO_WritePin(GPIOA, Flame_Detec_Pin, GPIO_PIN_SET);   // Encender LED3
	  			  break;
	  		  case 'B':
	  			  HAL_GPIO_WritePin(GPIOC, EV_Valve_Pin, GPIO_PIN_RESET); // Apagar LED4
	  			  break;
	  		  case 'C':
	  			  HAL_GPIO_WritePin(GPIOC, EV_Valve_Pin, GPIO_PIN_SET);   // Encender LED4
	  			  break;
	  		  default:
	  			  break;
            }
        }

        // Habilitar la recepción de otros caracteres
        HAL_UART_Receive_IT(&huart2, rxBuffer, sizeof(rxBuffer));
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
